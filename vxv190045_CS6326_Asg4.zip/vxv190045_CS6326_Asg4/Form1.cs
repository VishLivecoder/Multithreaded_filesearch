﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Media;
using System.Threading;

namespace vxv190045_CS6326_Asg4
{
    public partial class Form1 : Form
    {
        BackgroundWorker search_string;
        int count = 0;
        public SoundPlayer notifySound;

        public Form1()
        {
            InitializeComponent();
            //
            //initially, the values of total mtime and total number of lines will be 0
            //
            textBox3.Text = "0";
           

            search_string = new BackgroundWorker();
            search_string.DoWork += new DoWorkEventHandler(stringSearchMethod);
            search_string.WorkerSupportsCancellation = true;
            search_string.RunWorkerCompleted += new RunWorkerCompletedEventHandler (stringSearchRunCompleted);
            search_string.ProgressChanged += new ProgressChangedEventHandler(ProgressChanged);
            search_string.WorkerReportsProgress = true;



        }

        private int calculateSize(int lineLength, int lineNo, int fileLength)
        {
            int percComplete;
            percComplete = ((lineNo * 4834) / fileLength);         //lineno*48*100/fileLength
            
            Console.WriteLine("Inside :" + lineNo + " " + fileLength + " " + percComplete);
            return percComplete;
        }
        public void ProgressChanged(object o, ProgressChangedEventArgs e)
        {
            toolStripProgressBar1.Value = e.ProgressPercentage;
            toolStripStatusLabel2.Text = "("+ e.ProgressPercentage.ToString() +"/100"+ "%";
        }
        public void stringSearchRunCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                toolStripStatusLabel1.Text = "Cancelled Search";
                toolStripStatusLabel1.ForeColor = Color.Red;

                //Plays the cancelled sound to notify the user
                notifySound = new SoundPlayer(Properties.Resources.searchCancelled);
                textBox3.Text = count.ToString();
            }

            //Check to see if an error occurred in the background process
            else if (e.Error != null)
            {
                toolStripStatusLabel1.Text = "Error in search...Please try again";
                toolStripStatusLabel1.ForeColor = Color.Red;

            }
            else
            {
                if (count == 0)
                {
                    toolStripStatusLabel1.Text = "No Lines matched....Search completed";
                    toolStripStatusLabel1.ForeColor = Color.Green;
                    button2.Text = "Search text";
                    textBox3.Text = "0";
                    toolStripProgressBar1.Value = 100;
                    toolStripStatusLabel2.Text = "(100/100)%";
                    notifySound = new SoundPlayer(Properties.Resources.searchCompleted);


                }
                else
                {
                    toolStripStatusLabel1.Text = "Search Completed";
                    toolStripStatusLabel1.ForeColor = Color.Green;
                    count = 0;
                    button2.Text = "Search text";
                    toolStripProgressBar1.Value = 100;
                    toolStripStatusLabel2.Text = "(100/100)%";

                    notifySound = new SoundPlayer(Properties.Resources.searchCompleted);

                }
                
                




            }
            notifySound.Play();

        }
        private void stringSearchMethod(object sender, DoWorkEventArgs e)
        {
            string fileName = textBox1.Text;
            string searchString = textBox2.Text;



            using (StreamReader reader = File.OpenText(fileName))
            {
                string line = "";
                int linenumber = 1;

                int filelength = (int)new System.IO.FileInfo(fileName).Length;
                int percentage_done = 0;
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.Length > 0 && line.ToLower().Contains(searchString.ToLower()))
                    {
                        this.Invoke((MethodInvoker)(() => listView1.Items.Add(new ListViewItem(new[] { linenumber.ToString(), line }))));
                        count++;
                        Thread.Sleep(1);

                    }
                    linenumber++;
                    //Thread.Sleep(1);

                    //If the user clicks "Cancel", the CancellationPending flag is set to true
                    if (search_string.CancellationPending)
                    {
                        // Set the e.Cancel flag so that the WorkerCompleted event knows that the process was cancelled
                        e.Cancel = true;
                        return;
                    }

                    //implementing progress bar


                    if ((linenumber != 0) && (linenumber % 100 == 0))
                    {
                        percentage_done = calculateSize(line.Length, linenumber, filelength);
                        search_string.ReportProgress(percentage_done);
                    }
                        
                    


                }
                this.Invoke((MethodInvoker)(() => textBox3.Text = count.ToString()));



            }

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileWindow = new OpenFileDialog();
            this.listView1.Items.Clear();
            textBox2.Text = "";
            textBox3.Text = "";
            toolStripStatusLabel1.ForeColor = Color.Black;
            toolStripStatusLabel1.Text = "Search text";
            toolStripProgressBar1.Value = 0;



            try
            {
                if (fileWindow.ShowDialog() == DialogResult.OK)
                {
                    string fileToSearch = fileWindow.FileName;
                    textBox1.Text = fileToSearch;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not read the file");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                MessageBox.Show("Please Enter the Text to be searched");
            }
            else
            {
                if (button2.Text == "Cancel" && search_string.IsBusy)
                {
                    search_string.CancelAsync();

                    button2.Text = "Search text";

                    textBox1.Text = "";
                    textBox2.Text = "";

                    textBox3.Text = count.ToString();

                    this.Invoke((MethodInvoker)(() => toolStripStatusLabel1.Text = "Cancelled"));





                }
                else
                {
                    //clear the list view 

                    this.listView1.Items.Clear();
                    //making the search button as cancel button
                    button2.Text = "Cancel";

                    //making statusstrip text as searching in progress
                    this.Invoke((MethodInvoker)(() => toolStripStatusLabel1.Text = "Search in progress"));

                    search_string.RunWorkerAsync();






                }
            }


        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox2.Text))
            {
                //Enable the button
                button2.Enabled = true;
            }
            else
            {
                button2.Enabled = false;
            }
        }
       
    }
}
